#!/usr/bin/env node
/**
 * Rewrites the deployed themes.json so each theme's `href` points at the file
 * the build actually emitted.
 *
 * Why this exists: with `outputHashing: "all"` the lazy style bundles are
 * emitted as `theme-dark.<hash>.css`. A config file that hardcodes
 * `theme-dark.css` would then 404 in production while working perfectly in dev
 * — the worst kind of bug. Resolving the real names after the build keeps the
 * config authorable by hand and correct in every configuration.
 *
 * Usage: node scripts/write-theme-manifest.mjs dist/<app>/browser
 */
import { readdir, readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';

const outputDir = process.argv[2];

if (!outputDir) {
  console.error('Usage: node scripts/write-theme-manifest.mjs <build-output-dir>');
  process.exit(1);
}

const configPath = join(outputDir, 'config', 'themes.json');

let config;
try {
  config = JSON.parse(await readFile(configPath, 'utf8'));
} catch (error) {
  console.error(`[theme-manifest] Could not read ${configPath}: ${error.message}`);
  process.exit(1);
}

const emitted = (await readdir(outputDir)).filter((f) => f.endsWith('.css'));

let rewritten = 0;
const missing = [];

for (const theme of config.themes ?? []) {
  // "theme-dark.css" -> matches "theme-dark.css" or "theme-dark.A1B2C3D4.css"
  const base = theme.href.replace(/\.css$/, '');
  const pattern = new RegExp(`^${escapeRegExp(base)}(\\.[A-Za-z0-9]+)?\\.css$`);
  const match = emitted.find((file) => pattern.test(file));

  if (!match) {
    missing.push(theme.href);
    continue;
  }

  if (match !== theme.href) {
    theme.href = match;
    rewritten++;
  }
}

if (missing.length > 0) {
  // Failing the build is deliberate: shipping a config that points at files
  // which do not exist means the app boots with no theme at all.
  console.error(
    `[theme-manifest] No emitted stylesheet for: ${missing.join(', ')}.\n` +
      `Check the "styles" array in angular.json — each theme needs an entry with ` +
      `"inject": false and a matching "bundleName".`,
  );
  process.exit(1);
}

await writeFile(configPath, `${JSON.stringify(config, null, 2)}\n`);
console.log(
  `[theme-manifest] ${config.themes.length} theme(s) verified, ${rewritten} href(s) rewritten.`,
);

function escapeRegExp(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}
