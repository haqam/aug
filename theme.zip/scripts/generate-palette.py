"""
Generates a Material 3 tonal palette as a Sass map.

M3 'tone' is defined as CIELAB L*, so a tonal ramp is produced by holding hue and
chroma steady and sweeping L* across the required tone stops. Real M3 uses HCT
(a CAM16-based space) for chroma; LCh(ab) is a close enough approximation for a
hand-authored brand palette and needs no external dependency.

Out-of-gamut colors are resolved by reducing chroma until the color fits sRGB,
which preserves hue and lightness — the two things a tonal palette must keep.
"""
import math

TONES = [0, 10, 20, 25, 30, 35, 40, 50, 60, 70, 80, 90, 95, 98, 99, 100]
# The neutral ramp carries extra stops that M3 surface containers depend on.
NEUTRAL_TONES = sorted(set(TONES + [4, 6, 12, 17, 22, 24, 87, 92, 94, 96]))

D65 = (95.047, 100.0, 108.883)


def lab_to_xyz(L, a, b):
    fy = (L + 16) / 116
    fx = fy + a / 500
    fz = fy - b / 200

    def inv(t):
        return t ** 3 if t ** 3 > 0.008856 else (t - 16 / 116) / 7.787

    return inv(fx) * D65[0], inv(fy) * D65[1], inv(fz) * D65[2]


def xyz_to_srgb(x, y, z):
    x, y, z = x / 100, y / 100, z / 100
    r = x * 3.2404542 + y * -1.5371385 + z * -0.4985314
    g = x * -0.9692660 + y * 1.8760108 + z * 0.0415560
    b = x * 0.0556434 + y * -0.2040259 + z * 1.0572252

    def gamma(c):
        return 1.055 * (c ** (1 / 2.4)) - 0.055 if c > 0.0031308 else 12.92 * c

    return gamma(r), gamma(g), gamma(b)


def in_gamut(rgb, eps=1e-4):
    return all(-eps <= c <= 1 + eps for c in rgb)


def lch_to_hex(L, C, h_deg):
    """Converts LCh(ab) to a hex string, reducing chroma until it fits sRGB."""
    h = math.radians(h_deg)
    lo, hi = 0.0, C
    best = xyz_to_srgb(*lab_to_xyz(L, 0, 0))

    # Binary search the largest chroma that still lands inside sRGB.
    for _ in range(40):
        mid = (lo + hi) / 2
        rgb = xyz_to_srgb(*lab_to_xyz(L, mid * math.cos(h), mid * math.sin(h)))
        if in_gamut(rgb):
            best, lo = rgb, mid
        else:
            hi = mid

    return '#{:02x}{:02x}{:02x}'.format(
        *(max(0, min(255, round(c * 255))) for c in best))


def ramp(hue, chroma, tones=TONES):
    return {t: lch_to_hex(t, chroma, hue) for t in tones}


def sass_map(name, data, indent='  '):
    lines = [f'{indent}{name}: (']
    for tone, hex_value in data.items():
        lines.append(f'{indent}  {tone}: {hex_value},')
    lines.append(f'{indent}),')
    return '\n'.join(lines)


def build(palette_name, hues):
    """hues: dict of role -> (hue_degrees, chroma)"""
    primary = ramp(*hues['primary'])

    out = [
        '// GENERATED FILE — edit scripts/generate-palette.py and re-run instead.',
        '// npm run palette',
        '//',
        f'// {palette_name}: hand-authored tonal palette in Material 3 structure.',
        '// Tone numbers are CIELAB L* values, so 0 is black and 100 is white for',
        '// every ramp. Angular Material picks specific tones per role and per',
        '// color-scheme, which is why every stop has to be present.',
        '',
        '$primary-palette: (',
    ]
    for tone, hex_value in primary.items():
        out.append(f'  {tone}: {hex_value},')

    out.append(sass_map('secondary', ramp(*hues['secondary'])))
    out.append(sass_map('neutral', ramp(*hues['neutral'], tones=NEUTRAL_TONES)))
    out.append(sass_map('neutral-variant', ramp(*hues['neutral-variant'])))
    out.append(sass_map('error', ramp(*hues['error'])))
    out.append(');')
    out.append('')

    # Tertiary is exposed as its own palette so the theme file can pass it
    # separately to mat.theme().
    out.append('$tertiary-palette: (')
    for tone, hex_value in ramp(*hues['tertiary']).items():
        out.append(f'  {tone}: {hex_value},')
    out.append(sass_map('secondary', ramp(*hues['secondary'])))
    out.append(sass_map('neutral', ramp(*hues['neutral'], tones=NEUTRAL_TONES)))
    out.append(sass_map('neutral-variant', ramp(*hues['neutral-variant'])))
    out.append(sass_map('error', ramp(*hues['error'])))
    out.append(');')
    out.append('')

    return '\n'.join(out)


SAGE = {
    # Muted sage green — low chroma keeps it calm rather than "spring green".
    'primary': (140, 22),
    # Warmer olive, one step round the wheel from primary.
    'secondary': (110, 14),
    # Clay/terracotta accent for emphasis against all that green.
    'tertiary': (48, 34),
    # Warm grey rather than pure grey: a neutral at hue 80 keeps surfaces from
    # reading cold next to the green.
    'neutral': (80, 4),
    'neutral-variant': (105, 8),
    'error': (27, 60),
}

if __name__ == '__main__':
    import pathlib
    target = pathlib.Path(__file__).resolve().parent.parent / 'src/styles/themes/_sage-palette.scss'
    target.write_text(build('Sage / warm earth', SAGE))
    print(f'wrote {target}')
