# Angular 22 · Material theming

Three themes — **Light**, **Dark**, **Natural** — plus a **System** option, switched from a `mat-select` in the top right. Each theme is its own lazily-loaded CSS bundle, and the list of themes comes from a JSON config fetched at bootstrap rather than being compiled in.

```bash
npm install
npm start        # http://localhost:4200
npm test
npm run build    # ng build + theme manifest check
```

---

## How the switching works

```
public/config/themes.json         ← the registry: id, label, icon, href, colorScheme
        │  fetched at bootstrap (provideAppInitializer)
        ▼
ThemeConfigService                ← validates, normalises, falls back if unreachable
        ▼
ThemeService                      ← owns <link id="app-theme">, resolves "system"
        ▼
<link rel="stylesheet" href="theme-natural.css">
        ▼
--mat-sys-* custom properties     ← every component recolours, no component code runs
```

The whole switch is one `<link>` swap. Material emits its entire design system as `--mat-sys-*` custom properties, so replacing the stylesheet that defines them repaints every component — no `[class]` bindings, no per-component theme inputs.

### Three details that matter

**The old stylesheet is removed only after the new one loads.** Removing first leaves the page unstyled for the length of the request, which on a cold cache is a very visible white flash. `applyStylesheet()` appends the new `<link>`, waits for its `load` event, then removes the previous one.

**Rapid switching can't lose a race.** Every apply takes a generation number. If you click three themes quickly, a slow first response that arrives last is discarded instead of overwriting your actual choice.

**A failed load keeps the current theme.** A 404 on a theme file logs an error and leaves the page styled, rather than dropping you to unstyled HTML.

### Adding a theme

1. `src/styles/themes/theme-ocean.scss` — call `theme-base.build()` with your palettes.
2. Add it to `styles` in `angular.json` with `"inject": false` and `"bundleName": "theme-ocean"`.
3. Add an entry to `public/config/themes.json`.

Step 3 is data, not code: if the CSS file is already deployed you can add, rename, reorder or re-point a theme by editing the JSON on the server. Steps 1–2 need a rebuild because the stylesheet has to exist.

---

## Theming setup

`_theme-base.scss` holds the one `mat.theme()` call every theme shares, so a theme file is three lines:

```scss
@include theme-base.build(mat.$azure-palette, mat.$blue-palette, light);
```

**Light and dark are not two palettes.** Material emits every colour token as `light-dark(<light>, <dark>)`, so the real difference between `theme-light.scss` and `theme-dark.scss` is the `color-scheme` property. They're still separate bundles so a visitor downloads only the one they use — ~1.3 kB gzipped each.

**Natural uses a hand-authored palette.** `scripts/generate-palette.py` builds a Material 3 tonal palette (sage primary, clay tertiary, warm-grey neutrals). M3 tone is defined as CIELAB L\*, so each ramp holds hue and chroma steady and sweeps L\* across the required stops, reducing chroma when a colour falls outside sRGB — that preserves hue and lightness, which is what a tonal palette has to keep. Re-run with `npm run palette`.

Light and Dark deliberately use Material's shipped palettes instead, so the repo shows both the zero-effort path and the custom one.

---

## Layout

```
public/config/themes.json          runtime theme registry
scripts/generate-palette.py        generates _sage-palette.scss
scripts/write-theme-manifest.mjs   post-build href resolution + validation
src/styles.scss                    base styles (no colour)
src/styles/themes/
  _theme-base.scss                 shared mat.theme() call
  _sage-palette.scss               GENERATED
  theme-{light,dark,natural}.scss  one bundle each
src/app/core/
  theme.models.ts                  config contract
  theme-config.service.ts          fetch + validate + fallback
  theme.service.ts                 the link swap
src/app/layout/
  shell.ts                         toolbar
  theme-picker.ts                  the mat-select, top right
src/app/features/showcase/         demo pages
```

---

## The post-build script

`write-theme-manifest.mjs` scans the build output, matches each `href` in `themes.json` against the emitted files (allowing for a content hash), and rewrites the config to match.

As of Angular 22.1 the CLI does **not** hash `inject: false` style bundles — `theme-dark.css` stays `theme-dark.css` even under `outputHashing: "all"`, so the script currently rewrites nothing. It earns its place as a guard: if that behaviour ever changes, a config pointing at `theme-dark.css` would 404 in production while working perfectly in dev. It also fails the build if a configured theme has no matching stylesheet, which catches a mistyped `bundleName` at build time instead of at runtime.

---

## Verified

Built and type-checked against the real toolchain (Angular 22.1.5, Material 22.1.3, TypeScript 6.0):

```
Initial total        634.71 kB  |  139.31 kB transfer
theme-light.css        7.90 kB  |    1.25 kB
theme-dark.css         7.86 kB  |    1.27 kB
theme-natural.css      7.84 kB  |    1.26 kB
```

Contrast for the custom sage palette, checked against the compiled CSS — worst text pair **6.15:1**, comfortably past WCAG AA (4.5:1); `outline` on `surface` is 4.24:1 against a 3:1 non-text requirement.

Two things found and fixed during verification, worth knowing if you regenerate this setup:

- **Angular 22 requires TypeScript `>=6.0 <6.1`.** A `~5.9` devDependency fails `npm install` with ERESOLVE.
- **`provideAnimationsAsync()` breaks the build** unless `@angular/animations` is installed. Material has animated with CSS since v19, so it was removed rather than adding the package.

The 13 unit tests (`theme.service.spec.ts`, `theme-config.service.spec.ts`) type-check but were not executed — no Chrome in the verification sandbox. They use `data:text/css` URLs as theme hrefs so the service's real `load`/`error` handling runs without network or synthetic events. Run `npm test` locally.

Note for CI: production builds inline Google Fonts, which needs network access at build time. On an air-gapped runner, either self-host the fonts or set `"optimization": { "fonts": { "inline": false } }`.
