import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'showcase' },
  {
    path: 'showcase',
    title: 'Components',
    loadComponent: () => import('./features/showcase/showcase').then((m) => m.Showcase),
  },
  {
    path: 'tokens',
    title: 'Design tokens',
    loadComponent: () => import('./features/showcase/tokens').then((m) => m.Tokens),
  },
  { path: '**', redirectTo: 'showcase' },
];
