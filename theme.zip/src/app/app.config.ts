import {
  ApplicationConfig,
  provideAppInitializer,
  provideBrowserGlobalErrorListeners,
  provideZonelessChangeDetection,
  inject,
} from '@angular/core';
import { provideHttpClient, withFetch } from '@angular/common/http';
import { provideRouter, withComponentInputBinding } from '@angular/router';
import { routes } from './app.routes';
import { ThemeService } from './core/theme.service';

export const appConfig: ApplicationConfig = {
  providers: [
    provideBrowserGlobalErrorListeners(),
    provideZonelessChangeDetection(),
    provideRouter(routes, withComponentInputBinding()),
    provideHttpClient(withFetch()),

    // No provideAnimationsAsync(): Material components animate with CSS as of
    // v19+, so pulling in @angular/animations would add weight for nothing.

    // Bootstrap blocks until the config is fetched and the theme stylesheet has
    // loaded. That costs one round trip before first paint but guarantees the
    // app never renders unthemed and then repaints.
    provideAppInitializer(() => inject(ThemeService).initialize()),
  ],
};
