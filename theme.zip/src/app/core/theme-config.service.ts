import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { ThemeConfig, ThemeDefinition, SYSTEM_THEME_ID } from './theme.models';

/** Path is relative to <base href>, so the app still works under a sub-path. */
export const THEME_CONFIG_URL = 'config/themes.json';

/**
 * Last-resort config used when the JSON is missing or malformed. An
 * unreachable config file should degrade to an unstyled-but-working app rather
 * than a blank page, so this mirrors the bundles that ship with the build.
 */
const FALLBACK_CONFIG: ThemeConfig = {
  defaultThemeId: 'light',
  storageKey: 'app.theme',
  themes: [
    { id: 'light', label: 'Light', icon: 'light_mode', href: 'theme-light.css', colorScheme: 'light' },
    { id: 'dark', label: 'Dark', icon: 'dark_mode', href: 'theme-dark.css', colorScheme: 'dark' },
  ],
};

@Injectable({ providedIn: 'root' })
export class ThemeConfigService {
  private readonly http = inject(HttpClient);

  async load(): Promise<ThemeConfig> {
    try {
      const raw = await firstValueFrom(
        this.http.get<unknown>(THEME_CONFIG_URL, {
          // The config is deployed alongside the app and may be edited between
          // releases, so it must never be served from a stale cache.
          headers: { 'Cache-Control': 'no-cache' },
        }),
      );
      return this.validate(raw);
    } catch (error) {
      console.error('[theme] Falling back to built-in config.', error);
      return FALLBACK_CONFIG;
    }
  }

  /**
   * The config is deployable data, not compiled code, so a typo in it is a
   * runtime problem. Validating here turns "every component renders wrong" into
   * one clear console error plus a working fallback.
   */
  private validate(raw: unknown): ThemeConfig {
    if (!isRecord(raw)) throw new Error('Config root is not an object.');

    const themes = Array.isArray(raw['themes'])
      ? raw['themes'].map(toThemeDefinition).filter((t): t is ThemeDefinition => t !== null)
      : [];

    if (themes.length === 0) throw new Error('Config contains no valid themes.');

    const system = isRecord(raw['system']) && raw['system']['enabled'] === true
      ? {
          enabled: true,
          label: asString(raw['system']['label'], 'System'),
          icon: asString(raw['system']['icon'], 'brightness_auto'),
          lightThemeId: asString(raw['system']['lightThemeId'], themes[0].id),
          darkThemeId: asString(raw['system']['darkThemeId'], themes[0].id),
        }
      : undefined;

    const defaultThemeId = asString(raw['defaultThemeId'], themes[0].id);
    const known = new Set(themes.map((t) => t.id));
    const defaultIsValid =
      known.has(defaultThemeId) || (defaultThemeId === SYSTEM_THEME_ID && system?.enabled);

    if (!defaultIsValid) {
      console.warn(`[theme] Unknown defaultThemeId "${defaultThemeId}"; using "${themes[0].id}".`);
    }

    return {
      defaultThemeId: defaultIsValid ? defaultThemeId : themes[0].id,
      storageKey: asString(raw['storageKey'], 'app.theme'),
      system,
      themes,
    };
  }
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function asString(value: unknown, fallback: string): string {
  return typeof value === 'string' && value.length > 0 ? value : fallback;
}

/** Returns null (and warns) rather than throwing, so one bad entry does not
 *  take down the whole theme list. */
function toThemeDefinition(value: unknown): ThemeDefinition | null {
  if (
    !isRecord(value) ||
    typeof value['id'] !== 'string' ||
    typeof value['href'] !== 'string' ||
    (value['colorScheme'] !== 'light' && value['colorScheme'] !== 'dark')
  ) {
    console.warn('[theme] Skipping malformed theme entry.', value);
    return null;
  }

  const browserThemeColor = value['browserThemeColor'];

  return {
    id: value['id'],
    label: asString(value['label'], value['id']),
    icon: asString(value['icon'], 'palette'),
    href: value['href'],
    colorScheme: value['colorScheme'],
    ...(typeof browserThemeColor === 'string' ? { browserThemeColor } : {}),
  };
}
