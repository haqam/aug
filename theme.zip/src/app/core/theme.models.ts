/** A single selectable theme, backed by one lazily-loaded CSS bundle. */
export interface ThemeDefinition {
  readonly id: string;
  readonly label: string;
  /** Material Symbols ligature name shown in the picker. */
  readonly icon: string;
  /** URL of the theme stylesheet, relative to the app's base href. */
  readonly href: string;
  readonly colorScheme: 'light' | 'dark';
  /** Optional value for <meta name="theme-color">, which tints browser UI. */
  readonly browserThemeColor?: string;
}

/** Opt-in "follow the OS" entry, which maps to one of the real themes. */
export interface SystemThemeOption {
  readonly enabled: boolean;
  readonly label: string;
  readonly icon: string;
  readonly lightThemeId: string;
  readonly darkThemeId: string;
}

export interface ThemeConfig {
  /** Theme applied on first visit. May be SYSTEM_THEME_ID. */
  readonly defaultThemeId: string;
  /** localStorage key holding the visitor's choice. */
  readonly storageKey: string;
  readonly system?: SystemThemeOption;
  readonly themes: readonly ThemeDefinition[];
}

/** Reserved id: not a stylesheet, it defers to prefers-color-scheme. */
export const SYSTEM_THEME_ID = 'system';

/** What the picker renders — real themes plus the optional System entry. */
export interface ThemeChoice {
  readonly id: string;
  readonly label: string;
  readonly icon: string;
}
