import { DOCUMENT, Injectable, computed, inject, signal } from '@angular/core';
import { ThemeConfigService } from './theme-config.service';
import { SYSTEM_THEME_ID, ThemeChoice, ThemeConfig, ThemeDefinition } from './theme.models';

const LINK_ELEMENT_ID = 'app-theme';
const LOADING_CLASS = 'theme-loading';

/**
 * Owns the single <link> element that carries the active Material theme.
 *
 * Why swap a stylesheet rather than toggle a class: each theme is built as its
 * own CSS bundle (see angular.json), so a visitor downloads only the theme they
 * use. The cost is a network request on switch, which is why the old stylesheet
 * is kept in the document until the new one has finished loading.
 */
@Injectable({ providedIn: 'root' })
export class ThemeService {
  private readonly document = inject(DOCUMENT);
  private readonly configService = inject(ThemeConfigService);

  /** Guards against a slow load from an earlier click overwriting a newer one. */
  private applyGeneration = 0;
  private mediaQuery: MediaQueryList | null = null;

  private readonly config = signal<ThemeConfig | null>(null);

  /** The id the user picked — may be SYSTEM_THEME_ID. */
  readonly selectedId = signal<string>(SYSTEM_THEME_ID);

  /** True while a theme stylesheet is in flight. */
  readonly loading = signal(false);

  /** Everything the picker needs to render, System first when enabled. */
  readonly choices = computed<ThemeChoice[]>(() => {
    const config = this.config();
    if (!config) return [];

    const themes = config.themes.map(({ id, label, icon }) => ({ id, label, icon }));

    return config.system?.enabled
      ? [{ id: SYSTEM_THEME_ID, label: config.system.label, icon: config.system.icon }, ...themes]
      : themes;
  });

  /** The theme actually painted right now — never SYSTEM_THEME_ID. */
  readonly activeTheme = computed<ThemeDefinition | null>(() =>
    this.resolve(this.selectedId()),
  );

  /** Called from provideAppInitializer so the first paint is already themed. */
  async initialize(): Promise<void> {
    this.document.documentElement.classList.add(LOADING_CLASS);

    const config = await this.configService.load();
    this.config.set(config);

    this.watchSystemPreference();

    const stored = this.readStoredId(config);
    await this.setTheme(stored ?? config.defaultThemeId);
  }

  async setTheme(id: string): Promise<void> {
    const config = this.config();
    if (!config) throw new Error('ThemeService.initialize() has not completed.');

    const isSystem = id === SYSTEM_THEME_ID && config.system?.enabled === true;
    if (!isSystem && !config.themes.some((t) => t.id === id)) {
      console.warn(`[theme] Unknown theme "${id}"; ignoring.`);
      return;
    }

    this.selectedId.set(id);
    this.writeStoredId(config, id);

    const theme = this.resolve(id);
    if (theme) await this.applyStylesheet(theme);
  }

  /** Maps a selection (possibly "system") onto a concrete theme. */
  private resolve(id: string): ThemeDefinition | null {
    const config = this.config();
    if (!config) return null;

    if (id === SYSTEM_THEME_ID && config.system?.enabled) {
      const target = this.prefersDark() ? config.system.darkThemeId : config.system.lightThemeId;
      return config.themes.find((t) => t.id === target) ?? config.themes[0] ?? null;
    }

    return config.themes.find((t) => t.id === id) ?? null;
  }

  /**
   * Adds the new stylesheet, waits for it to load, and only then removes the
   * previous one. Removing first would leave the page unstyled for the duration
   * of the request, which on a cold cache is very visible.
   */
  private applyStylesheet(theme: ThemeDefinition): Promise<void> {
    const generation = ++this.applyGeneration;
    this.loading.set(true);

    return new Promise<void>((resolve) => {
      const previous = this.document.getElementById(LINK_ELEMENT_ID);

      const link = this.document.createElement('link');
      link.rel = 'stylesheet';
      link.href = theme.href;

      const finish = (ok: boolean) => {
        // A newer selection already started; this result is stale, so drop the
        // element instead of letting it win the race.
        if (generation !== this.applyGeneration) {
          link.remove();
          resolve();
          return;
        }

        if (ok) {
          previous?.remove();
          link.id = LINK_ELEMENT_ID;
          this.setBrowserThemeColor(theme);
        } else {
          console.error(`[theme] Failed to load "${theme.href}"; keeping the current theme.`);
          link.remove();
        }

        this.document.documentElement.classList.remove(LOADING_CLASS);
        this.loading.set(false);
        resolve();
      };

      link.addEventListener('load', () => finish(true), { once: true });
      link.addEventListener('error', () => finish(false), { once: true });

      this.document.head.appendChild(link);
    });
  }

  /** Tints browser chrome (Android address bar, iOS PWA status bar). */
  private setBrowserThemeColor(theme: ThemeDefinition): void {
    if (!theme.browserThemeColor) return;

    let meta = this.document.querySelector<HTMLMetaElement>('meta[name="theme-color"]');
    if (!meta) {
      meta = this.document.createElement('meta');
      meta.name = 'theme-color';
      this.document.head.appendChild(meta);
    }
    meta.content = theme.browserThemeColor;
  }

  /** Re-resolves while the selection is "system" and the OS preference flips. */
  private watchSystemPreference(): void {
    const view = this.document.defaultView;
    if (!view?.matchMedia) return;

    this.mediaQuery = view.matchMedia('(prefers-color-scheme: dark)');
    this.mediaQuery.addEventListener('change', () => {
      if (this.selectedId() !== SYSTEM_THEME_ID) return;

      const theme = this.resolve(SYSTEM_THEME_ID);
      if (theme) void this.applyStylesheet(theme);
    });
  }

  private prefersDark(): boolean {
    return this.mediaQuery?.matches ?? false;
  }

  // localStorage throws in Safari private mode and when cookies are blocked, so
  // persistence is best-effort and never allowed to break bootstrap.
  private readStoredId(config: ThemeConfig): string | null {
    try {
      return this.document.defaultView?.localStorage.getItem(config.storageKey) ?? null;
    } catch {
      return null;
    }
  }

  private writeStoredId(config: ThemeConfig, id: string): void {
    try {
      this.document.defaultView?.localStorage.setItem(config.storageKey, id);
    } catch {
      /* preference simply will not persist */
    }
  }
}
