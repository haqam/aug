import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { ThemeService } from './theme.service';
import { THEME_CONFIG_URL } from './theme-config.service';
import { SYSTEM_THEME_ID } from './theme.models';

// data: URLs load as real stylesheets, so the service's load/error handling is
// exercised for real without hitting the network or needing fake events.
const css = (label: string) => `data:text/css,%2F*${label}*%2F`;

const CONFIG = {
  defaultThemeId: 'light',
  storageKey: 'test.theme',
  system: {
    enabled: true,
    label: 'System',
    icon: 'brightness_auto',
    lightThemeId: 'light',
    darkThemeId: 'dark',
  },
  themes: [
    { id: 'light', label: 'Light', icon: 'light_mode', href: css('light'), colorScheme: 'light' },
    { id: 'dark', label: 'Dark', icon: 'dark_mode', href: css('dark'), colorScheme: 'dark' },
    {
      id: 'natural',
      label: 'Natural',
      icon: 'eco',
      href: css('natural'),
      colorScheme: 'light',
      browserThemeColor: '#faf9f6',
    },
  ],
};

describe('ThemeService', () => {
  let service: ThemeService;
  let httpTesting: HttpTestingController;

  const activeLink = () =>
    document.getElementById('app-theme') as HTMLLinkElement | null;

  /** Starts initialize(), answers the config request, and waits for the CSS. */
  async function boot(config: object = CONFIG): Promise<void> {
    const started = service.initialize();
    httpTesting.expectOne(THEME_CONFIG_URL).flush(config);
    await started;
  }

  beforeEach(() => {
    localStorage.removeItem('test.theme');
    document.getElementById('app-theme')?.remove();

    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()],
    });

    service = TestBed.inject(ThemeService);
    httpTesting = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpTesting.verify();
    document.getElementById('app-theme')?.remove();
  });

  it('applies the default theme and links exactly one stylesheet', async () => {
    await boot();

    expect(service.selectedId()).toBe('light');
    expect(service.activeTheme()?.id).toBe('light');
    expect(activeLink()?.href).toContain('light');
    expect(document.querySelectorAll('#app-theme').length).toBe(1);
  });

  it('offers System first, then every configured theme', async () => {
    await boot();

    expect(service.choices().map((c) => c.id)).toEqual([
      SYSTEM_THEME_ID,
      'light',
      'dark',
      'natural',
    ]);
  });

  it('replaces the stylesheet when a new theme is selected', async () => {
    await boot();
    await service.setTheme('natural');

    expect(service.activeTheme()?.id).toBe('natural');
    expect(activeLink()?.href).toContain('natural');
    // The previous stylesheet must be gone, or two themes would fight.
    expect(document.querySelectorAll('#app-theme').length).toBe(1);
  });

  it('persists the choice and restores it on the next boot', async () => {
    await boot();
    await service.setTheme('natural');

    expect(localStorage.getItem('test.theme')).toBe('natural');

    // A fresh service instance, same storage.
    TestBed.resetTestingModule();
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()],
    });
    service = TestBed.inject(ThemeService);
    httpTesting = TestBed.inject(HttpTestingController);

    await boot();
    expect(service.selectedId()).toBe('natural');
  });

  it('resolves "system" to a concrete theme rather than leaving it unset', async () => {
    await boot();
    await service.setTheme(SYSTEM_THEME_ID);

    expect(service.selectedId()).toBe(SYSTEM_THEME_ID);
    expect(['light', 'dark']).toContain(service.activeTheme()!.id);
    expect(activeLink()).not.toBeNull();
  });

  it('ignores an unknown theme id instead of clearing the current theme', async () => {
    await boot();
    await service.setTheme('does-not-exist');

    expect(service.selectedId()).toBe('light');
    expect(activeLink()?.href).toContain('light');
  });

  it('sets the browser theme-color when the theme declares one', async () => {
    await boot();
    await service.setTheme('natural');

    const meta = document.querySelector<HTMLMetaElement>('meta[name="theme-color"]');
    expect(meta?.content).toBe('#faf9f6');
  });

  it('keeps the current theme when a stylesheet fails to load', async () => {
    await boot();

    const broken = {
      ...CONFIG,
      themes: [...CONFIG.themes, {
        id: 'broken',
        label: 'Broken',
        icon: 'error',
        href: '/definitely-not-a-stylesheet-404.css',
        colorScheme: 'light',
      }],
    };

    // Re-boot with the broken theme available, then try to select it.
    TestBed.resetTestingModule();
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()],
    });
    service = TestBed.inject(ThemeService);
    httpTesting = TestBed.inject(HttpTestingController);
    await boot(broken);

    const before = activeLink()?.href;
    await service.setTheme('broken');

    expect(activeLink()?.href).toBe(before);
    expect(document.querySelectorAll('#app-theme').length).toBe(1);
  });

  it('falls back to a built-in config when themes.json cannot be fetched', async () => {
    const started = service.initialize();
    httpTesting.expectOne(THEME_CONFIG_URL).error(new ProgressEvent('error'));
    await started;

    // Fallback hrefs are real files in the build, absent under Karma — so the
    // link fails and no theme is applied, but the app must still be usable.
    expect(service.choices().length).toBeGreaterThan(0);
    expect(service.selectedId()).toBe('light');
  });
});
