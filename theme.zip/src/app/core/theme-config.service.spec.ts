import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { THEME_CONFIG_URL, ThemeConfigService } from './theme-config.service';

describe('ThemeConfigService', () => {
  let service: ThemeConfigService;
  let httpTesting: HttpTestingController;

  async function load(payload: object) {
    const promise = service.load();
    httpTesting.expectOne(THEME_CONFIG_URL).flush(payload);
    return promise;
  }

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()],
    });
    service = TestBed.inject(ThemeConfigService);
    httpTesting = TestBed.inject(HttpTestingController);
  });

  afterEach(() => httpTesting.verify());

  it('fills in optional fields with sensible defaults', async () => {
    const config = await load({
      themes: [{ id: 'light', href: 'theme-light.css', colorScheme: 'light' }],
    });

    expect(config.themes[0].label).toBe('light');
    expect(config.themes[0].icon).toBe('palette');
    expect(config.storageKey).toBe('app.theme');
    expect(config.defaultThemeId).toBe('light');
  });

  it('drops malformed entries but keeps the valid ones', async () => {
    const config = await load({
      themes: [
        { id: 'good', label: 'Good', href: 'a.css', colorScheme: 'light' },
        { id: 'no-href', label: 'Bad', colorScheme: 'light' },
        { id: 'bad-scheme', label: 'Bad', href: 'b.css', colorScheme: 'sepia' },
        'not-an-object',
      ],
    });

    expect(config.themes.map((t) => t.id)).toEqual(['good']);
  });

  it('falls back when defaultThemeId names a theme that does not exist', async () => {
    const config = await load({
      defaultThemeId: 'missing',
      themes: [{ id: 'light', href: 'a.css', colorScheme: 'light' }],
    });

    expect(config.defaultThemeId).toBe('light');
  });

  it('accepts "system" as the default only when the system option is enabled', async () => {
    const enabled = await load({
      defaultThemeId: 'system',
      system: { enabled: true, lightThemeId: 'light', darkThemeId: 'light' },
      themes: [{ id: 'light', href: 'a.css', colorScheme: 'light' }],
    });
    expect(enabled.defaultThemeId).toBe('system');

    const disabled = await load({
      defaultThemeId: 'system',
      themes: [{ id: 'light', href: 'a.css', colorScheme: 'light' }],
    });
    expect(disabled.defaultThemeId).toBe('light');
  });

  it('uses the built-in fallback when every entry is invalid', async () => {
    const config = await load({ themes: [] });

    expect(config.themes.length).toBeGreaterThan(0);
    expect(config.defaultThemeId).toBe('light');
  });
});
