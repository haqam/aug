import { Component } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { ThemePicker } from './theme-picker';

@Component({
  selector: 'app-shell',
  imports: [
    RouterOutlet,
    RouterLink,
    RouterLinkActive,
    MatToolbarModule,
    MatButtonModule,
    MatIconModule,
    ThemePicker,
  ],
  template: `
    <mat-toolbar class="toolbar">
      <mat-icon fontSet="material-symbols-outlined" class="logo">palette</mat-icon>
      <span class="brand">Material Theming</span>

      <nav class="nav">
        <a mat-button routerLink="/showcase" routerLinkActive="active">Components</a>
        <a mat-button routerLink="/tokens" routerLinkActive="active">Tokens</a>
      </nav>

      <!-- Pushes the picker to the top right, which is where users look for it. -->
      <span class="spacer"></span>
      <app-theme-picker />
    </mat-toolbar>

    <main class="content">
      <router-outlet />
    </main>
  `,
  styles: `
    .toolbar {
      position: sticky;
      top: 0;
      z-index: 10;
      gap: 0.75rem;
      background: var(--mat-sys-surface-container);
      color: var(--mat-sys-on-surface);
      border-bottom: 1px solid var(--mat-sys-outline-variant);
    }
    .logo {
      color: var(--mat-sys-primary);
    }
    .brand {
      font: var(--mat-sys-title-medium);
    }
    .nav {
      display: flex;
      gap: 0.25rem;
      margin-left: 1rem;
    }
    .nav a.active {
      background: var(--mat-sys-secondary-container);
      color: var(--mat-sys-on-secondary-container);
    }
    .spacer {
      flex: 1 1 auto;
    }
    .content {
      max-width: 68rem;
      margin: 0 auto;
      padding: 1.5rem 1.25rem 4rem;
    }

    @media (max-width: 700px) {
      .brand,
      .nav {
        display: none;
      }
    }
  `,
})
export class Shell {}
