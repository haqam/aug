import { Component, inject } from '@angular/core';
import { MatSelectModule } from '@angular/material/select';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { ThemeService } from '../core/theme.service';

@Component({
  selector: 'app-theme-picker',
  imports: [MatSelectModule, MatFormFieldModule, MatIconModule, MatProgressSpinnerModule],
  template: `
    <mat-form-field appearance="outline" subscriptSizing="dynamic" class="picker">
      <mat-label>Theme</mat-label>
      <mat-select
        [value]="theme.selectedId()"
        (valueChange)="onThemeChange($event)"
        panelClass="theme-picker-panel"
        aria-label="Select a theme"
      >
        <mat-select-trigger>
          <span class="trigger">
            <mat-icon fontSet="material-symbols-outlined">{{ activeIcon() }}</mat-icon>
            {{ activeLabel() }}
          </span>
        </mat-select-trigger>

        @for (choice of theme.choices(); track choice.id) {
          <mat-option [value]="choice.id">
            <mat-icon fontSet="material-symbols-outlined">{{ choice.icon }}</mat-icon>
            {{ choice.label }}
          </mat-option>
        }
      </mat-select>
    </mat-form-field>

    @if (theme.loading()) {
      <mat-progress-spinner
        mode="indeterminate"
        diameter="20"
        aria-label="Loading theme"
      />
    }
  `,
  styles: `
    :host {
      display: flex;
      align-items: center;
      gap: 0.75rem;
    }
    .picker {
      width: 11rem;
    }
    .trigger {
      display: inline-flex;
      align-items: center;
      gap: 0.5rem;
    }
    mat-option mat-icon {
      margin-right: 0.5rem;
    }
  `,
})
export class ThemePicker {
  protected readonly theme = inject(ThemeService);

  protected activeLabel(): string {
    return this.currentChoice()?.label ?? 'Theme';
  }

  protected activeIcon(): string {
    return this.currentChoice()?.icon ?? 'palette';
  }

  protected onThemeChange(id: string): void {
    // setTheme resolves once the stylesheet has loaded; nothing here needs to
    // wait on it, so the promise is intentionally not awaited.
    void this.theme.setTheme(id);
  }

  private currentChoice() {
    const id = this.theme.selectedId();
    return this.theme.choices().find((c) => c.id === id);
  }
}
