import { Component, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatChipsModule } from '@angular/material/chips';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatListModule } from '@angular/material/list';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSelectModule } from '@angular/material/select';
import { MatSliderModule } from '@angular/material/slider';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatTableModule } from '@angular/material/table';
import { MatTabsModule } from '@angular/material/tabs';
import { MatTooltipModule } from '@angular/material/tooltip';

interface Release {
  name: string;
  status: 'Shipped' | 'In review' | 'Blocked';
  owner: string;
  coverage: number;
}

@Component({
  selector: 'app-showcase',
  imports: [
    FormsModule,
    MatButtonModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatProgressBarModule,
    MatSelectModule,
    MatSliderModule,
    MatSlideToggleModule,
    MatTableModule,
    MatTabsModule,
    MatTooltipModule,
  ],
  templateUrl: './showcase.html',
  styleUrl: './showcase.scss',
})
export class Showcase {
  protected readonly columns = ['name', 'status', 'owner', 'coverage'] as const;

  protected readonly releases: Release[] = [
    { name: 'Search reindex', status: 'Shipped', owner: 'Priya', coverage: 92 },
    { name: 'Billing webhooks', status: 'In review', owner: 'Marco', coverage: 78 },
    { name: 'SSO migration', status: 'Blocked', owner: 'Dana', coverage: 41 },
    { name: 'Audit log export', status: 'Shipped', owner: 'Wei', coverage: 88 },
  ];

  protected readonly notifications = signal(true);
  protected readonly density = signal(2);
  protected readonly environment = signal('staging');
  protected readonly note = signal('');
}
