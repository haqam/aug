import { Component, inject } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { ThemeService } from '../../core/theme.service';

interface TokenGroup {
  readonly title: string;
  readonly tokens: readonly { name: string; on?: string }[];
}

@Component({
  selector: 'app-tokens',
  imports: [MatCardModule],
  template: `
    <h1 class="page-title">Design tokens</h1>
    <p class="page-subtitle">
      The live values of Material's system tokens for the
      <strong>{{ theme.activeTheme()?.label ?? '—' }}</strong> theme. Each swatch reads its
      colour straight from the CSS variable, so this page needs no per-theme code.
    </p>

    @for (group of groups; track group.title) {
      <mat-card appearance="outlined" class="group">
        <mat-card-header><mat-card-title>{{ group.title }}</mat-card-title></mat-card-header>
        <mat-card-content class="swatches">
          @for (token of group.tokens; track token.name) {
            <div
              class="swatch"
              [style.background]="'var(--mat-sys-' + token.name + ')'"
              [style.color]="'var(--mat-sys-' + (token.on ?? 'on-surface') + ')'"
            >
              <code>{{ token.name }}</code>
            </div>
          }
        </mat-card-content>
      </mat-card>
    }
  `,
  styles: `
    .page-title {
      font: var(--mat-sys-headline-medium);
      margin: 0 0 0.25rem;
    }
    .page-subtitle {
      font: var(--mat-sys-body-medium);
      color: var(--mat-sys-on-surface-variant);
      margin: 0 0 1.5rem;
      max-width: 44rem;
    }
    .group {
      margin-bottom: 1.25rem;
    }
    .swatches {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(11rem, 1fr));
      gap: 0.5rem;
    }
    .swatch {
      border-radius: var(--mat-sys-corner-small);
      border: 1px solid var(--mat-sys-outline-variant);
      padding: 1.25rem 0.75rem;
      font: var(--mat-sys-label-small);
      overflow-wrap: anywhere;
    }
  `,
})
export class Tokens {
  protected readonly theme = inject(ThemeService);

  protected readonly groups: readonly TokenGroup[] = [
    {
      title: 'Primary',
      tokens: [
        { name: 'primary', on: 'on-primary' },
        { name: 'on-primary', on: 'primary' },
        { name: 'primary-container', on: 'on-primary-container' },
        { name: 'on-primary-container', on: 'primary-container' },
      ],
    },
    {
      title: 'Secondary & tertiary',
      tokens: [
        { name: 'secondary', on: 'on-secondary' },
        { name: 'secondary-container', on: 'on-secondary-container' },
        { name: 'tertiary', on: 'on-tertiary' },
        { name: 'tertiary-container', on: 'on-tertiary-container' },
      ],
    },
    {
      title: 'Surfaces',
      tokens: [
        { name: 'surface', on: 'on-surface' },
        { name: 'surface-container-low', on: 'on-surface' },
        { name: 'surface-container', on: 'on-surface' },
        { name: 'surface-container-high', on: 'on-surface' },
        { name: 'surface-variant', on: 'on-surface-variant' },
        { name: 'inverse-surface', on: 'inverse-on-surface' },
      ],
    },
    {
      title: 'Error & outline',
      tokens: [
        { name: 'error', on: 'on-error' },
        { name: 'error-container', on: 'on-error-container' },
        { name: 'outline', on: 'surface' },
        { name: 'outline-variant', on: 'on-surface' },
      ],
    },
  ];
}
