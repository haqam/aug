import { TestBed } from '@angular/core/testing';
import { EventEnvelope, publishAs, resetBus, subscribe } from '@acme/mfe-events';
import { ProductCardComponent } from './product-card.component';
import { PRODUCTS } from './products';

describe('ProductCardComponent', () => {
  beforeEach(() => resetBus());

  async function render() {
    const fixture = TestBed.createComponent(ProductCardComponent);
    fixture.componentRef.setInput('product', PRODUCTS[0]);
    await fixture.whenStable();
    return fixture;
  }

  it('disables "Add to cart" when no user is logged in', async () => {
    const fixture = await render();
    const button = (fixture.nativeElement as HTMLElement).querySelector('button')!;
    expect(button.disabled).toBe(true);
  });

  it('publishes cart:item-added v2 when logged in', async () => {
    publishAs('shell', 'auth:session-changed', { user: { id: 'u1', displayName: 'Ada' } });
    const seen: EventEnvelope<'cart:item-added'>[] = [];
    subscribe('cart:item-added', (e) => seen.push(e));

    const fixture = await render();
    (fixture.nativeElement as HTMLElement).querySelector('button')!.click();

    expect(seen).toHaveLength(1);
    expect(seen[0].version).toBe(2);
    expect(seen[0].meta.source).toBe('catalog');
    expect(seen[0].payload).toEqual({
      sku: 'KB-01',
      name: 'Mechanical Keyboard',
      quantity: 1,
      price: { amount: 89, currency: 'USD' },
    });
  });
});
