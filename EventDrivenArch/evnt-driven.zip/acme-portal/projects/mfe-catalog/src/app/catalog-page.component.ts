import { Component } from '@angular/core';
import { ProductCardComponent } from './product-card.component';
import { PRODUCTS } from './products';

@Component({
  selector: 'catalog-page',
  imports: [ProductCardComponent],
  template: `
    <h1>Catalog <small>(mfe-catalog · :4201)</small></h1>
    <div class="grid">
      @for (p of products; track p.sku) {
        <catalog-product-card [product]="p" />
      }
    </div>
  `,
  styles: `
    small { font-size: .9rem; color: #6b7280; font-weight: normal; }
    .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 1rem; }
  `,
})
export class CatalogPage {
  protected readonly products = PRODUCTS;
}
