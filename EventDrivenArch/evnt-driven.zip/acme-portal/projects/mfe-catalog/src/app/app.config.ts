import {
  ApplicationConfig,
  isDevMode,
  provideAppInitializer,
  provideBrowserGlobalErrorListeners,
} from '@angular/core';
import { provideRouter } from '@angular/router';
import { publishAs, subscribe } from '@acme/mfe-events';
import { routes } from './app.routes';

/**
 * Used ONLY when the remote runs on its own (:4201). When the shell loads the
 * remote, only the exposed './routes' run — so this is the place to fake
 * what the shell normally provides.
 */
export const appConfig: ApplicationConfig = {
  providers: [
    provideBrowserGlobalErrorListeners(),
    provideRouter(routes),
    provideAppInitializer(() => {
      if (!isDevMode()) return;
      publishAs('dev-harness', 'auth:session-changed', { user: { id: 'dev', displayName: 'Dev User' } });
      subscribe('cart:item-added', (e) => console.info('[dev-harness] cart:item-added', e.payload));
      subscribe('nav:navigate', (e) => console.info('[dev-harness] nav:navigate', e.payload));
    }),
  ],
};
