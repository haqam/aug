import { Routes } from '@angular/router';

/** Exposed as './routes' — the shell mounts these under /catalog. */
export const CATALOG_ROUTES: Routes = [
  { path: '', loadComponent: () => import('./catalog-page.component').then((m) => m.CatalogPage) },
];
