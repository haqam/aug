import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';

/** Standalone-mode root. Not used when loaded into the shell. */
@Component({
  imports: [RouterOutlet],
  selector: 'app-root',
  template: `
    <p class="banner">mfe-catalog running standalone — events are logged to the console.</p>
    <router-outlet />
  `,
  styles: `
    :host { display: block; font-family: system-ui, sans-serif; padding: 1rem; }
    .banner { background: #fef3c7; padding: .5rem 1rem; border-radius: 6px; }
  `,
})
export class App {}
