export interface Product {
  sku: string;
  name: string;
  price: number;
}

export const PRODUCTS: Product[] = [
  { sku: 'KB-01', name: 'Mechanical Keyboard', price: 89 },
  { sku: 'MS-02', name: 'Wireless Mouse', price: 39 },
  { sku: 'MN-03', name: '27" Monitor', price: 249 },
  { sku: 'HS-04', name: 'Noise-cancelling Headset', price: 129 },
];
