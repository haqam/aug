import { Component, computed, input } from '@angular/core';
import { CurrencyPipe } from '@angular/common';
import { mfeEventSignal } from '@acme/mfe-events';
import { events } from './events';
import { Product } from './products';

/**
 * Publishes facts; knows nothing about the cart MFE or the shell's header badge.
 */
@Component({
  selector: 'catalog-product-card',
  imports: [CurrencyPipe],
  template: `
    <article>
      <h3>{{ product().name }}</h3>
      <p>{{ product().price | currency: 'USD' }}</p>
      <button type="button" (click)="add()" [disabled]="!loggedIn()">Add to cart</button>
      <button type="button" class="link" (click)="goToCart()">View cart →</button>
      @if (!loggedIn()) {
        <p class="hint">Log in to add items</p>
      }
    </article>
  `,
  styles: `
    article { border: 1px solid #e5e7eb; border-radius: 8px; padding: 1rem; }
    h3 { margin: 0 0 .25rem; font-size: 1rem; }
    button { margin-right: .5rem; cursor: pointer; }
    .link { background: none; border: none; color: #2563eb; padding: 0; }
    .hint { color: #9ca3af; font-size: .8rem; margin: .5rem 0 0; }
  `,
})
export class ProductCardComponent {
  readonly product = input.required<Product>();

  private readonly session = mfeEventSignal('auth:session-changed');
  protected readonly loggedIn = computed(() => !!this.session()?.payload.user);

  protected add(): void {
    const p = this.product();
    events.publish(
      'cart:item-added',
      { sku: p.sku, name: p.name, quantity: 1, price: { amount: p.price, currency: 'USD' } },
      { version: 2 },
    );
  }

  protected goToCart(): void {
    events.publish('nav:navigate', { path: '/cart' });
  }
}
