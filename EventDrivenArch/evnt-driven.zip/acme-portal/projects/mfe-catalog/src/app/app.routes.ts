import { Routes } from '@angular/router';
import { CATALOG_ROUTES } from './catalog.routes';

/** Standalone mode (ng serve mfe-catalog) only — the shell uses CATALOG_ROUTES directly. */
export const routes: Routes = CATALOG_ROUTES;
