import { computed, effect, Injectable, signal } from '@angular/core';
import { onMfeEvent } from '@acme/mfe-events';
import { events } from './events';

export interface CartLine {
  sku: string;
  name: string;
  qty: number;
  amount: number;
}

/**
 * The cart MFE OWNS cart state. It listens for facts from other MFEs and
 * announces its derived state as the sticky `cart:updated` event.
 *
 * `providedIn: 'root'`: './routes' and './CartWidget' come from the same remote
 * build, so they share this class and get one instance — fine INSIDE one MFE.
 * Other MFEs must never inject it.
 */
@Injectable({ providedIn: 'root' })
export class CartStore {
  private readonly _lines = signal<CartLine[]>([]);
  readonly lines = this._lines.asReadonly();
  readonly count = computed(() => this._lines().reduce((n, l) => n + l.qty, 0));
  readonly total = computed(() => this._lines().reduce((t, l) => t + l.qty * l.amount, 0));

  constructor() {
    onMfeEvent('cart:item-added', (e) => {
      // Version tolerance: an older catalog may still emit v1 (price: number).
      const p = e.payload as unknown as {
        sku: string;
        name?: string;
        quantity: number;
        price: number | { amount: number };
      };
      const amount = typeof p.price === 'number' ? p.price : p.price.amount;
      this.add({ sku: p.sku, name: p.name ?? p.sku, qty: p.quantity, amount });
    });

    onMfeEvent('auth:session-changed', (e) => {
      if (!e.payload.user) this._lines.set([]);
    });

    effect(() => {
      events.publish('cart:updated', { itemCount: this.count(), total: this.total() });
    });
  }

  remove(sku: string): void {
    this._lines.update((lines) => lines.filter((l) => l.sku !== sku));
  }

  private add(line: CartLine): void {
    this._lines.update((lines) => {
      const hit = lines.find((l) => l.sku === line.sku);
      return hit
        ? lines.map((l) => (l === hit ? { ...l, qty: l.qty + line.qty } : l))
        : [...lines, line];
    });
  }
}
