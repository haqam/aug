import { TestBed } from '@angular/core/testing';
import { publishAs, resetBus, subscribe } from '@acme/mfe-events';
import { CartStore } from './cart.store';

describe('CartStore', () => {
  beforeEach(() => resetBus());

  const addKeyboard = (quantity = 1) =>
    publishAs(
      'test',
      'cart:item-added',
      { sku: 'KB-01', name: 'Keyboard', quantity, price: { amount: 10, currency: 'USD' } },
      { version: 2 },
    );

  it('aggregates items and publishes cart:updated', () => {
    const store = TestBed.inject(CartStore);
    const seen: unknown[] = [];
    subscribe('cart:updated', (e) => seen.push(e.payload), { replay: false });

    addKeyboard(2);
    addKeyboard(1);
    TestBed.tick(); // flush the effect that publishes cart:updated

    expect(store.count()).toBe(3);
    expect(store.lines()).toHaveLength(1);
    expect(seen.at(-1)).toEqual({ itemCount: 3, total: 30 });
  });

  it('tolerates v1 payloads (price as a number)', () => {
    const store = TestBed.inject(CartStore);
    publishAs('legacy', 'cart:item-added', { sku: 'OLD', quantity: 1, price: 7 } as never, {
      version: 1 as never,
    });

    expect(store.total()).toBe(7);
  });

  it('clears the cart on logout', () => {
    const store = TestBed.inject(CartStore);
    addKeyboard();
    publishAs('shell', 'auth:session-changed', { user: null });

    expect(store.count()).toBe(0);
  });
});
