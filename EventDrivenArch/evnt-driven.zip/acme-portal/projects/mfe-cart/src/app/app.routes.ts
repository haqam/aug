import { Routes } from '@angular/router';
import { CART_ROUTES } from './cart.routes';

/** Standalone mode (ng serve mfe-cart) only — the shell uses CART_ROUTES directly. */
export const routes: Routes = CART_ROUTES;
