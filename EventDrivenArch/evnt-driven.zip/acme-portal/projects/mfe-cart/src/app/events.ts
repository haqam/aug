import { createPublisher } from '@acme/mfe-events';

export const events = createPublisher('cart');
