import { Component, inject } from '@angular/core';
import { CurrencyPipe } from '@angular/common';
import { CartStore } from './cart.store';

/** Exposed as './CartWidget' — the shell renders it in its header. */
@Component({
  selector: 'cart-widget',
  imports: [CurrencyPipe],
  template: `<span class="widget">🛒 {{ store.count() }} · {{ store.total() | currency: 'USD' }}</span>`,
  styles: `.widget { font-size: .9rem; }`,
})
export class CartWidgetComponent {
  protected readonly store = inject(CartStore);
}
