import { Routes } from '@angular/router';

/** Exposed as './routes' — the shell mounts these under /cart. */
export const CART_ROUTES: Routes = [
  { path: '', loadComponent: () => import('./cart-page.component').then((m) => m.CartPage) },
];
