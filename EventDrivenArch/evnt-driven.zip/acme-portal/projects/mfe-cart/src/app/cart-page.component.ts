import { Component, inject } from '@angular/core';
import { CurrencyPipe } from '@angular/common';
import { events } from './events';
import { CartStore } from './cart.store';

@Component({
  selector: 'cart-page',
  imports: [CurrencyPipe],
  template: `
    <h1>Cart <small>(mfe-cart · :4202)</small></h1>
    @if (store.lines().length === 0) {
      <p>Your cart is empty.</p>
      <button type="button" (click)="continueShopping()">Browse catalog</button>
    } @else {
      <table>
        <thead>
          <tr><th>Item</th><th>Qty</th><th>Price</th><th></th></tr>
        </thead>
        <tbody>
          @for (l of store.lines(); track l.sku) {
            <tr>
              <td>{{ l.name }}</td>
              <td>{{ l.qty }}</td>
              <td>{{ l.qty * l.amount | currency: 'USD' }}</td>
              <td><button type="button" (click)="store.remove(l.sku)">Remove</button></td>
            </tr>
          }
        </tbody>
        <tfoot>
          <tr><th colspan="2">Total</th><th>{{ store.total() | currency: 'USD' }}</th><th></th></tr>
        </tfoot>
      </table>
      <button type="button" (click)="continueShopping()">← Continue shopping</button>
    }
  `,
  styles: `
    small { font-size: .9rem; color: #6b7280; font-weight: normal; }
    table { border-collapse: collapse; width: 100%; margin-bottom: 1rem; }
    th, td { text-align: left; padding: .5rem; border-bottom: 1px solid #e5e7eb; }
    button { cursor: pointer; }
  `,
})
export class CartPage {
  protected readonly store = inject(CartStore);

  protected continueShopping(): void {
    // Logical navigation request — the shell owns the router.
    events.publish('nav:navigate', { path: '/catalog' });
  }
}
