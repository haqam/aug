import {
  ApplicationConfig,
  isDevMode,
  provideAppInitializer,
  provideBrowserGlobalErrorListeners,
} from '@angular/core';
import { provideRouter } from '@angular/router';
import { publishAs, subscribe } from '@acme/mfe-events';
import { routes } from './app.routes';

/**
 * Used ONLY when the remote runs on its own (:4202). When the shell loads the
 * remote, only the exposed modules run — so this is the place to fake what the
 * shell and the catalog normally provide.
 */
export const appConfig: ApplicationConfig = {
  providers: [
    provideBrowserGlobalErrorListeners(),
    provideRouter(routes),
    provideAppInitializer(() => {
      if (!isDevMode()) return;
      publishAs('dev-harness', 'auth:session-changed', { user: { id: 'dev', displayName: 'Dev User' } });
      subscribe('nav:navigate', (e) => console.info('[dev-harness] nav:navigate', e.payload));
      // Seed the cart after the store has subscribed.
      setTimeout(() =>
        publishAs(
          'dev-harness',
          'cart:item-added',
          { sku: 'DEV-1', name: 'Fake item', quantity: 2, price: { amount: 10, currency: 'USD' } },
          { version: 2 },
        ),
      );
    }),
  ],
};
