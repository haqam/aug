import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { CartWidgetComponent } from './cart-widget.component';

/** Standalone-mode root. Not used when loaded into the shell. */
@Component({
  imports: [RouterOutlet, CartWidgetComponent],
  selector: 'app-root',
  template: `
    <p class="banner">mfe-cart running standalone. Widget preview: <cart-widget /></p>
    <router-outlet />
  `,
  styles: `
    :host { display: block; font-family: system-ui, sans-serif; padding: 1rem; }
    .banner { background: #fef3c7; padding: .5rem 1rem; border-radius: 6px; }
  `,
})
export class App {}
