import { EventEnvelope, EventName, PayloadOf, STICKY_EVENTS, VersionOf } from '../contract';

/**
 * Framework-agnostic event bus. No Angular imports here, so a React/Vue remote
 * or an Angular Elements remote on another Angular version can use it too.
 *
 * State is anchored on `globalThis` via `Symbol.for`: even if a version
 * mismatch makes Native Federation load two copies of this library, both
 * copies still talk over the same EventTarget and sticky cache.
 */
const KEY = Symbol.for('acme.mfe-events.v1');

interface BusState {
  target: EventTarget;
  sticky: Map<EventName, EventEnvelope>;
}

function state(): BusState {
  const g = globalThis as unknown as Record<symbol, BusState | undefined>;
  return (g[KEY] ??= { target: new EventTarget(), sticky: new Map() });
}

const sticky = new Set<EventName>(STICKY_EVENTS);

export interface PublishOptions<T extends EventName> {
  version?: VersionOf<T>;
  correlationId?: string;
  /** Re-use an existing event id (used by the cross-tab bridge). */
  id?: string;
  timestamp?: number;
}

export function publishAs<T extends EventName>(
  source: string,
  type: T,
  payload: PayloadOf<T>,
  opts: PublishOptions<T> = {},
): EventEnvelope<T> {
  const envelope: EventEnvelope<T> = Object.freeze({
    type,
    version: opts.version ?? (1 as VersionOf<T>),
    // Clone + freeze: no subscriber can mutate what others receive.
    payload: deepFreeze(structuredClone(payload)),
    meta: Object.freeze({
      id: opts.id ?? crypto.randomUUID(),
      source,
      timestamp: opts.timestamp ?? Date.now(),
      correlationId: opts.correlationId,
    }),
  });

  const s = state();
  if (sticky.has(type)) s.sticky.set(type, envelope);
  s.target.dispatchEvent(new CustomEvent(type, { detail: envelope }));
  return envelope;
}

export function subscribe<T extends EventName>(
  type: T,
  handler: (e: EventEnvelope<T>) => void,
  opts: { replay?: boolean } = {},
): () => void {
  const safeHandler = (e: EventEnvelope<T>) => {
    // Error isolation: a buggy MFE handler must not break the others.
    try {
      handler(e);
    } catch (err) {
      console.error(`[mfe-events] handler for "${type}" threw`, err);
    }
  };
  const listener = (ev: Event) => safeHandler((ev as CustomEvent<EventEnvelope<T>>).detail);

  const s = state();
  s.target.addEventListener(type, listener);

  if (opts.replay !== false) {
    const last = s.sticky.get(type) as EventEnvelope<T> | undefined;
    if (last) safeHandler(last); // synchronous, so signals start with the right value
  }
  return () => s.target.removeEventListener(type, listener);
}

/** Latest sticky value of an event, if any. */
export function peek<T extends EventName>(type: T): EventEnvelope<T> | undefined {
  return state().sticky.get(type) as EventEnvelope<T> | undefined;
}

export interface Publisher {
  readonly source: string;
  publish<T extends EventName>(type: T, payload: PayloadOf<T>, opts?: PublishOptions<T>): EventEnvelope<T>;
}

/** Each MFE creates one publisher tagged with its name. */
export function createPublisher(source: string): Publisher {
  return {
    source,
    publish: (type, payload, opts) => publishAs(source, type, payload, opts),
  };
}

/** Tests only: drop all listeners and sticky state. */
export function resetBus(): void {
  delete (globalThis as unknown as Record<symbol, unknown>)[KEY];
}

function deepFreeze<T>(value: T): T {
  if (value && typeof value === 'object') {
    Object.values(value).forEach(deepFreeze);
    Object.freeze(value);
  }
  return value;
}
