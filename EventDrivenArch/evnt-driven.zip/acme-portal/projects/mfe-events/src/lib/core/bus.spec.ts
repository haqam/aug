import { createPublisher, peek, publishAs, resetBus, subscribe } from './bus';

describe('mfe-events bus', () => {
  beforeEach(() => resetBus());

  it('delivers events to subscribers with an envelope', () => {
    const seen: string[] = [];
    subscribe('nav:navigate', (e) => seen.push(`${e.meta.source}:${e.payload.path}`));

    createPublisher('catalog').publish('nav:navigate', { path: '/cart' });

    expect(seen).toEqual(['catalog:/cart']);
  });

  it('replays sticky events to late subscribers, but not facts', () => {
    publishAs('shell', 'auth:session-changed', { user: { id: 'u1', displayName: 'Ada' } });
    publishAs('catalog', 'nav:navigate', { path: '/x' });

    const auth: unknown[] = [];
    const nav: unknown[] = [];
    subscribe('auth:session-changed', (e) => auth.push(e.payload.user?.id));
    subscribe('nav:navigate', (e) => nav.push(e.payload.path));

    expect(auth).toEqual(['u1']);
    expect(nav).toEqual([]);
    expect(peek('auth:session-changed')?.payload.user?.displayName).toBe('Ada');
  });

  it('freezes payloads so subscribers cannot mutate each other’s data', () => {
    let payload: any;
    subscribe('cart:updated', (e) => (payload = e.payload));
    publishAs('cart', 'cart:updated', { itemCount: 1, total: 5 });

    expect(Object.isFrozen(payload)).toBe(true);
  });

  it('isolates a throwing handler from the others', () => {
    const errorSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
    const seen: number[] = [];
    subscribe('cart:updated', () => {
      throw new Error('boom');
    });
    subscribe('cart:updated', (e) => seen.push(e.payload.itemCount));

    publishAs('cart', 'cart:updated', { itemCount: 3, total: 9 });

    expect(seen).toEqual([3]);
    expect(errorSpy).toHaveBeenCalled();
    errorSpy.mockRestore();
  });

  it('stops delivering after unsubscribe', () => {
    const seen: string[] = [];
    const off = subscribe('nav:navigate', (e) => seen.push(e.payload.path));
    publishAs('t', 'nav:navigate', { path: '/a' });
    off();
    publishAs('t', 'nav:navigate', { path: '/b' });

    expect(seen).toEqual(['/a']);
  });
});
