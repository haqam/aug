import { EventEnvelope, EventName } from '../contract';
import { publishAs, subscribe } from './bus';

/**
 * Forwards selected events to other tabs of the same origin (e.g. logout in
 * one tab logs out every tab). Call it ONCE, from the shell only.
 */
export function bridgeAcrossTabs(types: readonly EventName[], channelName = 'acme-mfe-events'): () => void {
  if (typeof BroadcastChannel === 'undefined') return () => {};

  const channel = new BroadcastChannel(channelName);
  // Ids of events that arrived from another tab; they must not be echoed back.
  const fromOtherTab = new Set<string>();

  const offs = types.map((type) =>
    subscribe(
      type,
      (e) => {
        if (fromOtherTab.delete(e.meta.id)) return;
        channel.postMessage(e);
      },
      { replay: false },
    ),
  );

  channel.onmessage = ({ data }: MessageEvent<EventEnvelope>) => {
    if (!types.includes(data.type)) return;
    fromOtherTab.add(data.meta.id);
    publishAs(data.meta.source, data.type, data.payload as never, {
      version: data.version as never,
      id: data.meta.id,
      timestamp: data.meta.timestamp,
      correlationId: data.meta.correlationId,
    });
  };

  return () => {
    offs.forEach((off) => off());
    channel.close();
  };
}
