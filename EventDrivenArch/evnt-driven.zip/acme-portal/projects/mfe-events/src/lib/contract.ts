/**
 * The event contract: the ONLY API shared between the shell and the MFEs.
 * Treat it like a public REST API — additive changes are free, breaking
 * changes bump `version` and consumers must tolerate both during migration.
 */
export interface EventMap {
  // STATE-like events: carry the current state and are replayed to late subscribers (sticky).
  'auth:session-changed': {
    version: 1;
    payload: { user: { id: string; displayName: string } | null };
  };
  'cart:updated': { version: 1; payload: { itemCount: number; total: number } };

  // FACT-like events: one-off notifications, never replayed.
  'cart:item-added': {
    version: 2;
    payload: { sku: string; name: string; quantity: number; price: { amount: number; currency: string } };
  };
  'nav:navigate': { version: 1; payload: { path: string; replace?: boolean } };
}

export type EventName = keyof EventMap;
export type PayloadOf<T extends EventName> = EventMap[T]['payload'];
export type VersionOf<T extends EventName> = EventMap[T]['version'];

export interface EventMeta {
  /** Unique id, used for dedupe and tracing. */
  id: string;
  /** Which MFE emitted it, e.g. "catalog". */
  source: string;
  timestamp: number;
  /** Ties request/response pairs together. */
  correlationId?: string;
}

export interface EventEnvelope<T extends EventName = EventName> {
  type: T;
  version: VersionOf<T>;
  payload: PayloadOf<T>;
  meta: EventMeta;
}

export const STICKY_EVENTS: readonly EventName[] = ['auth:session-changed', 'cart:updated'];
