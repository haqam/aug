import { assertInInjectionContext, DestroyRef, inject, Signal, signal } from '@angular/core';
import { Observable } from 'rxjs';
import { EventEnvelope, EventName } from '../contract';
import { peek, subscribe } from '../core/bus';

/**
 * Subscribe for the lifetime of the current injection context
 * (component, directive, service or route injector). Cleans up automatically,
 * so navigating away from a remote route never leaks handlers.
 */
export function onMfeEvent<T extends EventName>(
  type: T,
  handler: (e: EventEnvelope<T>) => void,
  opts?: { replay?: boolean },
): void {
  assertInInjectionContext(onMfeEvent);
  const off = subscribe(type, handler, opts);
  inject(DestroyRef).onDestroy(off);
}

/**
 * Latest value of an event as a read-only signal, seeded from the sticky cache.
 * In a zoneless app, setting the signal schedules change detection — no NgZone needed.
 */
export function mfeEventSignal<T extends EventName>(type: T): Signal<EventEnvelope<T> | undefined> {
  assertInInjectionContext(mfeEventSignal);
  const value = signal<EventEnvelope<T> | undefined>(peek(type));
  onMfeEvent(type, (e) => value.set(e), { replay: false });
  return value.asReadonly();
}

/** RxJS flavour for teams that want operators (debounce, switchMap, ...). */
export function mfeEvent$<T extends EventName>(type: T, replay = true): Observable<EventEnvelope<T>> {
  return new Observable((subscriber) => subscribe(type, (e) => subscriber.next(e), { replay }));
}
