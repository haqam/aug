import { Component, computed, inject, resource, Type } from '@angular/core';
import { NgComponentOutlet } from '@angular/common';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { loadRemoteModule } from '@angular-architects/native-federation';
import { mfeEventSignal } from '@acme/mfe-events';
import { AuthService } from './auth.service';

@Component({
  selector: 'app-header',
  imports: [RouterLink, RouterLinkActive, NgComponentOutlet],
  template: `
    <header>
      <strong class="brand">ACME Portal</strong>
      <nav>
        <a routerLink="/catalog" routerLinkActive="active">Catalog</a>
        <a routerLink="/cart" routerLinkActive="active">
          Cart
          @if (count() > 0) {
            <span class="badge" data-testid="cart-badge">{{ count() }}</span>
          }
        </a>
      </nav>

      <!-- Component exposed by mfe-cart, rendered inside the shell's layout -->
      <div class="widget">
        <!-- Check hasValue() first: reading value() while in error state throws. -->
        @if (cartWidget.hasValue()) {
          <ng-container *ngComponentOutlet="cartWidget.value()" />
        } @else if (cartWidget.error()) {
          <span class="muted">Cart unavailable</span>
        }
      </div>

      <div class="session">
        @if (auth.user(); as u) {
          <span>Hi, {{ u.displayName }}</span>
          <button type="button" (click)="auth.logout()">Log out</button>
        } @else {
          <button type="button" (click)="auth.login('Ada Lovelace')">Log in</button>
        }
      </div>
    </header>
  `,
  styles: `
    header { display: flex; gap: 1.5rem; align-items: center; padding: .75rem 1.25rem;
             background: #1f2937; color: #f9fafb; flex-wrap: wrap; }
    .brand { font-size: 1.1rem; }
    nav { display: flex; gap: 1rem; }
    a { color: #d1d5db; text-decoration: none; }
    a.active { color: #fff; font-weight: 600; }
    .badge { background: #ef4444; color: #fff; border-radius: 999px; padding: 0 .5rem; font-size: .8rem; }
    .widget { margin-left: auto; }
    .muted { color: #9ca3af; }
    .session { display: flex; gap: .5rem; align-items: center; }
    button { cursor: pointer; }
  `,
})
export class HeaderComponent {
  protected readonly auth = inject(AuthService);
  private readonly cart = mfeEventSignal('cart:updated');
  protected readonly count = computed(() => this.cart()?.payload.itemCount ?? 0);

  protected readonly cartWidget = resource({
    loader: () =>
      loadRemoteModule<{ CartWidgetComponent: Type<unknown> }>('mfe-cart', './CartWidget').then(
        (m) => m.CartWidgetComponent,
      ),
  });
}
