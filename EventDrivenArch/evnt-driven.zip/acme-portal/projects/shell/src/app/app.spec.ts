import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { publishAs, resetBus } from '@acme/mfe-events';
import { HeaderComponent } from './header.component';

// The header lazily loads a remote widget; simulate the remote being offline.
vi.mock('@angular-architects/native-federation', () => ({
  loadRemoteModule: () => Promise.reject(new Error('remote offline')),
}));

describe('HeaderComponent', () => {
  beforeEach(async () => {
    resetBus();
    await TestBed.configureTestingModule({
      imports: [HeaderComponent],
      providers: [provideRouter([])],
    }).compileComponents();
  });

  it('shows the cart badge from cart:updated events published by a remote', async () => {
    const fixture = TestBed.createComponent(HeaderComponent);
    await fixture.whenStable();
    const el = fixture.nativeElement as HTMLElement;
    expect(el.querySelector('[data-testid="cart-badge"]')).toBeNull();

    publishAs('cart', 'cart:updated', { itemCount: 3, total: 42 });
    await fixture.whenStable();

    expect(el.querySelector('[data-testid="cart-badge"]')?.textContent?.trim()).toBe('3');
  });

  it('reflects the sticky auth session', async () => {
    publishAs('shell', 'auth:session-changed', { user: { id: 'u1', displayName: 'Ada' } });
    const fixture = TestBed.createComponent(HeaderComponent);
    await fixture.whenStable();

    expect((fixture.nativeElement as HTMLElement).textContent).toContain('Hi, Ada');
  });

  it('degrades gracefully when the cart remote is unavailable', async () => {
    const fixture = TestBed.createComponent(HeaderComponent);
    await fixture.whenStable();

    expect((fixture.nativeElement as HTMLElement).textContent).toContain('Cart unavailable');
  });
});
