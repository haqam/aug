import { computed, Injectable } from '@angular/core';
import { mfeEventSignal } from '@acme/mfe-events';
import { events } from './events';

const STORAGE_KEY = 'acme.demo.user';

/**
 * The shell owns authentication and announces it as ONE sticky state event
 * (`auth:session-changed`). Remotes never call this service directly.
 *
 * Demo only: the "session" lives in localStorage. Swap in your OIDC library.
 */
@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly session = mfeEventSignal('auth:session-changed');
  readonly user = computed(() => this.session()?.payload.user ?? null);

  restoreSession(): void {
    events.publish('auth:session-changed', { user: readStoredUser() });
  }

  login(displayName: string): void {
    const user = { id: crypto.randomUUID(), displayName };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(user));
    events.publish('auth:session-changed', { user });
  }

  logout(): void {
    localStorage.removeItem(STORAGE_KEY);
    events.publish('auth:session-changed', { user: null });
  }
}

function readStoredUser(): { id: string; displayName: string } | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}
