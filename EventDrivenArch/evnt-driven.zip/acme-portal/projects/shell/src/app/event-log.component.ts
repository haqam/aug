import { Component, signal } from '@angular/core';
import { DatePipe, JsonPipe } from '@angular/common';
import { EventEnvelope, EventName, onMfeEvent } from '@acme/mfe-events';

const WATCHED: EventName[] = ['auth:session-changed', 'cart:item-added', 'cart:updated', 'nav:navigate'];

/** Dev aid: shows every bus event with its source MFE, so you can see the flow live. */
@Component({
  selector: 'app-event-log',
  imports: [DatePipe, JsonPipe],
  template: `
    <details open>
      <summary>Event bus log ({{ entries().length }})</summary>
      <ol reversed>
        @for (e of entries(); track e.meta.id) {
          <li>
            <code>{{ e.meta.timestamp | date: 'HH:mm:ss.SSS' }}</code>
            <b>{{ e.type }}</b> <span class="src">from {{ e.meta.source }}</span>
            <code class="payload">{{ e.payload | json }}</code>
          </li>
        }
      </ol>
    </details>
  `,
  styles: `
    details { margin: 1.5rem auto; max-width: 960px; padding: 0 1.25rem; font-size: .85rem; }
    ol { max-height: 240px; overflow: auto; padding-left: 2rem; }
    li { margin: .25rem 0; }
    .src { color: #6b7280; }
    .payload { display: block; color: #374151; white-space: pre-wrap; word-break: break-all; }
  `,
})
export class EventLogComponent {
  protected readonly entries = signal<EventEnvelope[]>([]);

  constructor() {
    for (const type of WATCHED) {
      onMfeEvent(type, (e) => this.entries.update((list) => [e as EventEnvelope, ...list].slice(0, 50)));
    }
  }
}
