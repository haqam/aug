import { Component } from '@angular/core';

@Component({
  selector: 'app-remote-unavailable',
  template: `
    <section class="fallback">
      <h2>This section is temporarily unavailable</h2>
      <p>The micro frontend could not be loaded. Is its dev server running?</p>
    </section>
  `,
  styles: `
    .fallback { padding: 2rem; border: 1px dashed #c33; border-radius: 8px; color: #a22; }
  `,
})
export class RemoteUnavailable {}
