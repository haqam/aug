import { Routes } from '@angular/router';
import { loadRemoteModule } from '@angular-architects/native-federation';
import { RemoteUnavailable } from './remote-unavailable.component';

/** If a remote is down, show a fallback instead of crashing the shell. */
const fallback: Routes = [{ path: '**', component: RemoteUnavailable }];

export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'catalog' },
  {
    path: 'catalog',
    loadChildren: () =>
      loadRemoteModule('mfe-catalog', './routes')
        .then((m) => m.CATALOG_ROUTES)
        .catch(() => fallback),
  },
  {
    path: 'cart',
    loadChildren: () =>
      loadRemoteModule('mfe-cart', './routes')
        .then((m) => m.CART_ROUTES)
        .catch(() => fallback),
  },
  { path: '**', redirectTo: 'catalog' },
];
