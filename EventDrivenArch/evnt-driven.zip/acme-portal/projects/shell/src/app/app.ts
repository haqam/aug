import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { HeaderComponent } from './header.component';
import { EventLogComponent } from './event-log.component';

@Component({
  imports: [RouterOutlet, HeaderComponent, EventLogComponent],
  selector: 'app-root',
  styleUrl: './app.css',
  templateUrl: './app.html',
})
export class App {}
