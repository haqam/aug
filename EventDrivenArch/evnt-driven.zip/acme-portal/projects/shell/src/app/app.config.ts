import {
  ApplicationConfig,
  inject,
  provideAppInitializer,
  provideBrowserGlobalErrorListeners,
} from '@angular/core';
import { provideRouter, Router } from '@angular/router';
import { bridgeAcrossTabs, subscribe } from '@acme/mfe-events';
import { routes } from './app.routes';
import { AuthService } from './auth.service';

export const appConfig: ApplicationConfig = {
  providers: [
    provideBrowserGlobalErrorListeners(),
    provideRouter(routes),
    provideAppInitializer(() => {
      const router = inject(Router);

      // Remotes request navigation by logical path; they never touch the shell's Router.
      subscribe('nav:navigate', ({ payload }) => {
        router.navigateByUrl(payload.path, { replaceUrl: payload.replace });
      });

      // Logging in/out in one tab updates every tab. Bridge once, shell only.
      bridgeAcrossTabs(['auth:session-changed']);

      // Publishes auth:session-changed (sticky) before any remote mounts.
      inject(AuthService).restoreSession();
    }),
  ],
};
