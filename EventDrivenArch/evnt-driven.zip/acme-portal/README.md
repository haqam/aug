# ACME Portal — Event-driven Micro Frontends (Angular 22 + Native Federation)

A runnable reference for **event-driven communication between a shell and micro frontends**:

| Project | Role | Port | What it shows |
|---|---|---|---|
| `projects/shell` | Dynamic host | 4200 | Owns auth + routing, renders a remote widget in its header, event log |
| `projects/mfe-catalog` | Remote | 4201 | Publishes `cart:item-added` and `nav:navigate` facts |
| `projects/mfe-cart` | Remote | 4202 | Owns cart state (signals), publishes sticky `cart:updated`, exposes `./CartWidget` |
| `projects/mfe-events` | Library | – | Event contract, framework-agnostic bus, Angular signal adapter, cross-tab bridge |

Versions: Angular 22.2, `@angular-architects/native-federation` 22.2 (Native Federation v4), zoneless, standalone components.

## Run it

```bash
npm install
npm start          # serves shell :4200, catalog :4201, cart :4202 together
```

Open http://localhost:4200, click **Log in**, add products, and watch the **Event bus log** at the bottom.
Open a second tab and log out in one — the other tab follows (BroadcastChannel bridge).

Run a remote on its own (it fakes the shell's events in dev mode):

```bash
npm run start:cart   # http://localhost:4202
```

Other scripts:

```bash
npm test             # unit tests for all four projects (Vitest)
npm run build        # production builds into dist/
```

> If you have a `PORT` environment variable set, `ng serve` uses it for every app and the remotes
> fail with "Port 4200 is already in use". Unset it before `npm start`.

## How the pieces fit

```
Catalog ──cart:item-added──▶ ┌────────────────────┐ ──▶ CartStore (mfe-cart)
Catalog ──nav:navigate─────▶ │  @acme/mfe-events  │ ──▶ Shell Router
Shell   ──auth:session-changed (sticky)──▶        │ ──▶ Catalog buttons, CartStore (clear on logout)
Cart    ──cart:updated (sticky)──────────▶        │ ──▶ Shell header badge
                             └────────────────────┘
```

- **Contract** — `projects/mfe-events/src/lib/contract.ts`. The only API shared between MFEs.
  State-like events (`auth:session-changed`, `cart:updated`) are *sticky*: late subscribers get the latest value.
  Fact-like events (`cart:item-added`, `nav:navigate`) are never replayed.
- **Core bus** — `lib/core/bus.ts`. No Angular imports. Anchored on `globalThis[Symbol.for(...)]`,
  so even duplicated copies of the library share one channel. Payloads are cloned and frozen;
  a throwing handler can't break other MFEs.
- **Angular adapter** — `lib/angular/mfe-events.angular.ts`: `mfeEventSignal()`, `onMfeEvent()` (auto-cleanup
  via `DestroyRef`), `mfeEvent$()` for RxJS.
- **Sharing** — `@acme/mfe-events` is a tsconfig path mapping (`tsconfig.json`), which Native Federation shares
  automatically as one bundle across shell and remotes.
- **Fault isolation** — the shell catches `loadRemoteModule` failures and shows a fallback route / "Cart unavailable".
- **Standalone remotes** — each remote's `app.config.ts` runs only when served alone; it publishes fake shell events.
  When loaded into the shell, only the exposed modules (`./routes`, `./CartWidget`) run.

## Where to look first

| File | Concept |
|---|---|
| `projects/shell/src/app/app.config.ts` | Shell subscribes to `nav:navigate`, bridges tabs, restores session |
| `projects/shell/src/app/app.routes.ts` | `loadRemoteModule` with fallback |
| `projects/shell/src/app/header.component.ts` | Signals from events + remote component via `resource()` |
| `projects/mfe-catalog/src/app/product-card.component.ts` | Publishing facts |
| `projects/mfe-cart/src/app/cart.store.ts` | Consuming events, version tolerance, publishing derived state |
| `projects/*/federation.config.mjs` | Exposes + shared config |
| `projects/shell/public/federation.manifest.json` | Remote URLs (swap per environment) |
